UMEED FOUNDATION WEBSITE

1. Open index.html to preview the site.
2. To publish it for free, create an account on GitHub and upload index.html to a repository.
3. Enable GitHub Pages for the repository.
4. For a custom domain, buy a domain and connect it through the hosting provider.
5. After the website is live, add it to Google Search Console and submit your sitemap.

IMPORTANT:
- Replace the placeholder impact numbers with real, verifiable numbers.
- Use real contact/payment details only after your organisation and donation process are properly set up.
- Before accepting public donations, make sure your NGO/entity and payment/tax compliance are appropriate for your jurisdiction.
